package daff.tools

class Rpm {

    final script

    Rpm(script) {
        this.script = script
    }

    void rpmbuild() {
        def wsRoot = script.env.WORKSPACE
        script.println("${script.env.WORKSPACE}")
        script.sh "rpmbuild --define '_topdir ${wsRoot}/rpm' -ba ${wsRoot}/rpm/SPECS/service.spec"
    }
}
