package daff

interface Globals {
    static String CMD_NOMAD = "/opt/nomad/nomad"
    static String NOMAD_ADDR = "http://192.168.1.100:4646"
    static String RAW_REPO = 'http://prodesk:8081/repository/daff-bin'
}
