package daff

static def checkout(script) {
    def vars = script.checkout script.scm
    script.sh 'git submodule update --init'
    script.env.GIT_URL = vars.GIT_URL
    script.env.GIT_BRANCH = vars.GIT_BRANCH
    script.env.GIT_AUTHOR_EMAIL = vars.GIT_AUTHOR_EMAIL
    script.env.GIT_AUTHOR_NAME = vars.GIT_AUTHOR_NAME
    script.env.GIT_COMMIT = vars.GIT_COMMIT
    script.env.GIT_COMMITTER_EMAIL = vars.GIT_COMMITTER_EMAIL
    script.env.GIT_COMMITTER_NAME = vars.GIT_COMMITTER_NAME
    script.env.GIT_URL = vars.GIT_URL
    String cmd = 'git log -1 --pretty=fuller'
    String res = script.sh(script: cmd, returnStdout: true)
    script.println("${res}")
}