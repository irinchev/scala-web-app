package daff

import org.jenkinsci.plugins.pipeline.utility.steps.fs.FileWrapper

final class SbtPipeline implements BasePipeline {

    final Script context
    final CommonSteps commonSteps

    SbtPipeline(Script context, Map props) {
        this.context = context
        this.context.env = props
        this.commonSteps = new CommonSteps(context)
    }

    void execute() {
        try {
            context.stage("[SBT] Execute") {
                this.commonSteps.checkout()
                build()
                uploadToNexus()
                deployToNomad()
            }
            context.stage("[SBT] Post") {
                this.context.archiveArtifacts(artifacts: "target/universal/*.zip", fingerprint: true)
            }
        } catch(e) {
            commonSteps.error(e)
            context.error(e.message)
        }
    }

    void build() {
        def out = context.sh(
                script: "/opt/sbt/bin/sbt -no-colors -Dsbt.log.noformat=true universal:packageBin",
                returnStdout: false
        )
    }

    void uploadToNexus() {
        def zipFile = findResultingZip()
        def prjName = findProjectName()
        def nexusRepo = Globals.RAW_REPO << '/' << prjName << '/' << zipFile.name
        context.env.BIN_SCRIPT = zipFile.name.replaceAll("(?<!^)[.][^.]*\$", "") + "/bin/" + prjName
        context.env.RAW_REPO_URL = nexusRepo
        this.commonSteps.info "Uploading ${zipFile} to ${nexusRepo}"
        context.sh(
                script: "curl -v -u uploader:uploader --upload-file ${zipFile} ${nexusRepo}",
                returnStdout: false
        )
    }

    void deployToNomad() {
        def url = context.env.RAW_REPO_URL
        def bin = context.env.BIN_SCRIPT
        if(url) {
            def job = context.readFile "build/deploy.nomad"
            if(job) {
                def jobSource = job.replace("@@URL@@", url).replace("@@BIN@@", bin)
                this.commonSteps.info jobSource
                context.withEnv(["NOMAD_ADDR=${Globals.NOMAD_ADDR}"]) {
                    def out = context.sh(
                            script: "printf '%s' '$jobSource' | ${Globals.CMD_NOMAD} job run -",
                            returnStdout: true
                    ).trim()
                }
            }
        }
    }

    FileWrapper findResultingZip() {
        def files = context.findFiles(glob: 'target/universal/*.zip')
        if(files.size() != 1) {
            throw new Exception("Multiple or no resulting zip files found in target/universal")
        }
        this.commonSteps.info "Zip files in target/universal: ${files}"
        return files[0]
    }

    String findProjectName() {
        def out = context.sh(
                script: "/opt/sbt/bin/sbt -Dsbt.supershell=false -error 'print name'",
                returnStdout: true
        ).replaceAll("\\n.*", "").trim()
        this.commonSteps.info "Project name resolved to ${out}"
        return out
    }
}
