package daff

interface BasePipeline {
    abstract void execute()
}