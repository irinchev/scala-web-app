package daff

import daff.tools.Git
import daff.tools.Rpm

final class Steps {

    static Map<String,Object> DEFAULTS = [
            jdk: "Java11"
    ]

    final script
    final jdk

    Steps(script, Map<String,Object> args = [:]) {
        this.script = script
        this.jdk = args.getOrDefault("jdk", DEFAULTS.jdk)
    }

    boolean setup(ProjectType projectType) {
        script.stage("Setup") {
            script.timeout(time: 5, unit: 'MINUTES') {
                checkout()
                configureTools()
            }
        }
    }

    def buildBinRpm() {
        script.stage("Build Service RPM") {
            script.timeout(time: 5, unit: 'MINUTES') {
                rpmbuild()
                cleanup()
            }
        }
    }

    def checkout() {
        def git = new Git(script)
        git.checkout()
    }

    def rpmbuild() {
        def rpm = new Rpm(script)
        rpm.rpmbuild()
    }

    def cleanup() {
        cleanWs()
    }

    def configureTools() {
        script.env.JAVA_HOME = script.tool jdk
    }

}
