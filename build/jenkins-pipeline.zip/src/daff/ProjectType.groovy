package daff

enum ProjectType {
    BIN_RPM,
    LIB_RPM
}