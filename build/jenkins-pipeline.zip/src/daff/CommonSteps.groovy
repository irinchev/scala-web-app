package daff

class CommonSteps {
    final context

    CommonSteps(context) {
        this.context = context
    }

    def info(msg) {
        this.context.println("\033[1;92m[INF] ${msg} \033[0m")
    }

    def error(msg) {
        this.context.println("\033[1;41m[ERR] ${msg} \033[0m")
    }

    def checkout() {
        def vars = this.context.checkout this.context.scm
        this.context.sh 'git submodule update --init'
        this.context.env.GIT_URL = vars.GIT_URL
        this.context.env.GIT_BRANCH = vars.GIT_BRANCH
        this.context.env.GIT_AUTHOR_EMAIL = vars.GIT_AUTHOR_EMAIL
        this.context.env.GIT_AUTHOR_NAME = vars.GIT_AUTHOR_NAME
        this.context.env.GIT_COMMIT = vars.GIT_COMMIT
        this.context.env.GIT_COMMITTER_EMAIL = vars.GIT_COMMITTER_EMAIL
        this.context.env.GIT_COMMITTER_NAME = vars.GIT_COMMITTER_NAME
        this.context.env.GIT_URL = vars.GIT_URL
        String cmd = 'git log -1 --pretty=fuller'
        String res = this.context.sh(script: cmd, returnStdout: true)
        this.context.println("${res}")
    }

}
