package daff

import com.lesfurets.jenkins.unit.BasePipelineTest
import org.junit.Before
import org.junit.Test

class PipelineTest extends BasePipelineTest {

    @Override
    @Before
    void setUp() throws Exception {
        //scriptRoots += 'src/test/jenkins'
        super.setUp()
    }

    @Test
    void testSerialization() throws Exception {
        def script = runScript('vars/buildAndDeploy.groovy')
        try {
            script.execute()
        } catch (e) {
            throw e
        } finally {
            printCallStack()
        }
    }
}
