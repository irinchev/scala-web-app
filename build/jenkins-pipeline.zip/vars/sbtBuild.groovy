def call(buildPlan = [:]) {
    node(buildPlan.jenkinsNode) {
        stage('init') {
            def sbtHome = tool name: 'Sbt146', type: 'org.jvnet.hudson.plugins.SbtPluginBuilder$SbtInstallation'
            env.sbt = "/opt/sbt/bin/sbt -no-colors -batch"
        }
        stage('Build') {
            sh "${sbt} 'set test in assembly := {}' assembly"
            archive includes: 'target/scala-*/toto.jar'
        }
    }
}