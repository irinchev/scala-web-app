import groovy.json.*

def call(buildPlan = [:]) {


        //println this.getMetaClass().getMethods().each { println it }
        //println this.getMetaClass().getProperties().each { println it }
    node("master") {
        cleanWs()
        vars = checkout scm
        sh 'git submodule update --init'
        sh 'git clean -fdx'
        def sbtHome = tool 'Sbt146'
        //def sbt = "${sbtHome}/bin/sbt -no-colors -batch"

        //vars = this.checkout this.scm
        //println vars
        println "AAAAAAAAAAAAA"
        this.properties.each { println "$it.key -> $it.value" }
//        this.getMetaClass().getProperties().each {
//            println it.dump()
//        }

        timeout(time: 15, unit: 'MINUTES') {
            try {
                //sh "${tool name: 'Sbt146', type:'org.jvnet.hudson.plugins.SbtPluginBuilder$SbtInstallation'}/bin/sbt compile"
                //sh "/opt/sbt/bin/sbt -Dsbt.supershell=false -error \"print version\"\n"
                //sh "/opt/sbt/bin/sbt -no-colors -batch 'compile'"
                sh "/opt/sbt/bin/sbt -no-colors -batch 'universal:packageBin'"
                //sbt('Sbt146', 'test', '-Dsbt.log.noformat=true', '-Xmx2G -Xms512M', 'subproject')
                archiveArtifacts artifacts: "target/universal/*.zip", fingerprint: true
                println aa
                def ms = buildPlan.size()
                println "BUILDPLAN Size $ms"
                buildPlan.each { entry -> println "$entry.key = $entry.value" }
                println new JsonBuilder( this ).toPrettyString()
            } catch (err) {
                this.println("$err")
            } finally {
                //deleteDir()
            }
        }
    }
}