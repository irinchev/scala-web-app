import daff.SbtPipeline
import groovy.json.JsonBuilder

def call(Map config = [:]) {
    def pipeline = new SbtPipeline(this, config)
    node("master") {
        ansiColor('xterm') {
            timeout(time: 15, unit: 'MINUTES') {
                cleanWs()
                pipeline.execute()
            }
        }
    }
}