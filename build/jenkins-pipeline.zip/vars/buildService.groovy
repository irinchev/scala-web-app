def call(buildPlan = [:]) {
    node(buildPlan.jenkinsNode) {
        stage("Install") {
            sh "npm install"
        }
    }
}