def call(Map args = [:]) {
    node {
        jdk = tool name: 'JDK14'
        env.JAVA_HOME = "${jdk}"

        stage("Build") {
            build()
            deploy()
        }
    }

}