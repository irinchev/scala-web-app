import daff.Steps
import static daff.ProjectType.BIN_RPM

def call(buildPlan = [:]) {
    def steps = new Steps(this, buildPlan)
    node("master") {
        timeout(time: 15, unit: 'MINUTES') {
            try {
                steps.setup(BIN_RPM)
                steps.buildBinRpm()
            } catch (err) {
                this.println("$err")
            } finally {
                //deleteDir()
            }
        }
    }
}